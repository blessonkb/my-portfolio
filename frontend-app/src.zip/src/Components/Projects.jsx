import { Card } from 'react-bootstrap';

const Projects = () => {
  const projects = [
    {
      id: 1,
      title: 'E-Commerce Platform',
      description: 'A full-stack e-commerce platform built with React, Node.js, Express, and MongoDB. Features include user authentication, product catalog, shopping cart, and payment integration.',
      image: 'images/project1.jpg',
      liveUrl: 'https://example.com'
    },
    {
      id: 2,
      title: 'Social Media Dashboard',
      description: 'A responsive social media analytics dashboard with real-time data visualization using React and Chart.js. Built with RESTful API integration for seamless data fetching.',
      image: 'images/project2.jpg',
      liveUrl: 'https://example.com'
    },
    
  ];

  return (
    <section 
      id="projects" 
      style={{ 
        backgroundColor: '#f50202', 
        padding: '5rem 0',
        minHeight: '100vh'
      }}
    >
      <div className="container">
        <h2 
          className="text-center mb-5"
          style={{ 
            fontSize: '2.5rem', 
            fontWeight: 'bold',
            color: 'white',
            marginBottom: '4rem'
          }}
        >
          My Masterpiece Collection
        </h2>
        
        <div className="row g-4">
          {projects.map((project) => (
            <div key={project.id} className="col-lg-4 col-md-6 col-sm-12">
              <Card 
                style={{ 
                  backgroundColor: '#2a2a2a', 
                  border: 'none',
                  height: '100%',
                  transition: 'transform 0.3s, box-shadow 0.3s',
                  cursor: 'pointer'
                }}
                className="project-card"
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = 'translateY(-10px)';
                  e.currentTarget.style.boxShadow = '0 10px 30px rgba(220, 53, 69, 0.3)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = 'translateY(0)';
                  e.currentTarget.style.boxShadow = 'none';
                }}
              >
                <div 
                  style={{ 
                    width: '100%', 
                    height: '250px', 
                    overflow: 'hidden',
                    backgroundColor: '#1a1a1a'
                  }}
                >
                  <img
                    src={project.image}
                    alt={project.title}
                    className="img-fluid"
                    style={{
                      width: '100%',
                      height: '100%',
                      objectFit: 'cover',
                      filter: 'grayscale(100%)',
                      transition: 'filter 0.3s'
                    }}
                    onMouseEnter={(e) => {
                      e.target.style.filter = 'grayscale(0%)';
                    }}
                    onMouseLeave={(e) => {
                      e.target.style.filter = 'grayscale(100%)';
                    }}
                  />
                </div>
                <Card.Body style={{ padding: '1.5rem' }}>
                  <Card.Title 
                    style={{ 
                      color: 'white', 
                      fontSize: '1.5rem',
                      fontWeight: 'bold',
                      marginBottom: '1rem'
                    }}
                  >
                    {project.title}
                  </Card.Title>
                  <Card.Text 
                    style={{ 
                      color: '#999', 
                      fontSize: '0.95rem',
                      lineHeight: '1.6',
                      marginBottom: '1.5rem'
                    }}
                  >
                    {project.description}
                  </Card.Text>
                  <a
                    href={project.liveUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn text-white"
                    style={{
                      backgroundColor: '#dc3545',
                      border: 'none',
                      padding: '0.5rem 2rem',
                      borderRadius: '0',
                      fontWeight: '500',
                      textDecoration: 'none',
                      display: 'inline-block',
                      transition: 'background-color 0.3s'
                    }}
                    onMouseEnter={(e) => {
                      e.target.style.backgroundColor = '#c82333';
                    }}
                    onMouseLeave={(e) => {
                      e.target.style.backgroundColor = '#dc3545';
                    }}
                  >
                    Live
                  </a>
                </Card.Body>
              </Card>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;

