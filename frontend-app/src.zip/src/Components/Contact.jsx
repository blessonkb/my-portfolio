const Contact = () => {
  return (
    <section 
      id="contact" 
      style={{ 
        backgroundColor: 'white', 
        padding: '5rem 0',
        minHeight: '70vh',
        display: 'flex',
        alignItems: 'center'
      }}
    >
      <div className="container text-center">
        <h2 
          className="mb-4"
          style={{ 
            fontSize: '2.5rem', 
            fontWeight: 'bold',
            color: 'white',
            marginBottom: '3rem'
          }}
        >
          Ways To Contact Me
        </h2>
        
        <div className="row justify-content-center">
          <div className="col-lg-8">
            <div 
              style={{ 
                backgroundColor: '#2a2a2a', 
                padding: '3rem',
                borderRadius: '10px'
              }}
            >
              <p 
                className="mb-3"
                style={{ 
                  fontSize: '1.1rem',
                  color: '#999',
                  marginBottom: '2rem'
                }}
              >
                Email:
                <a 
                  href="mailto:blesonkb1@gmail.com" 
                  style={{ 
                    color: '#dc3545',
                    textDecoration: 'none',
                    marginLeft: '0.5rem',
                    fontWeight: '500'
                  }}
                >
                  blesonkb1@gmail.com
                </a>
              </p>
              
              <p 
                className="mb-4"
                style={{ 
                  fontSize: '1.1rem',
                  color: '#999'
                }}
              >
                LinkedIn: 
                <a 
                  href="#" 
                  style={{ 
                    color: '#dc3545',
                    textDecoration: 'none',
                    marginLeft: '0.5rem',
                    fontWeight: '500'
                  }}
                >
                  Connect with me on LinkedIn
                </a>
              </p>

              <div className="d-flex justify-content-center gap-3 mt-4">
                <a 
                  href="#" 
                  style={{ 
                    color: '#dc3545',
                    fontSize: '2rem',
                    transition: 'transform 0.3s'
                  }}
                  onMouseEnter={(e) => {
                    e.target.style.transform = 'scale(1.2)';
                  }}
                  onMouseLeave={(e) => {
                    e.target.style.transform = 'scale(1)';
                  }}
                >
                  <i className="fab fa-github"></i>
                </a>
                <a 
                  href="#" 
                  style={{ 
                    color: '#dc3545',
                    fontSize: '2rem',
                    transition: 'transform 0.3s'
                  }}
                  onMouseEnter={(e) => {
                    e.target.style.transform = 'scale(1.2)';
                  }}
                  onMouseLeave={(e) => {
                    e.target.style.transform = 'scale(1)';
                  }}
                >
                  <i className="fab fa-linkedin-in"></i>
                </a>
                <a 
                  href="#" 
                  style={{ 
                    color: '#dc3545',
                    fontSize: '2rem',
                    transition: 'transform 0.3s'
                  }}
                  onMouseEnter={(e) => {
                    e.target.style.transform = 'scale(1.2)';
                  }}
                  onMouseLeave={(e) => {
                    e.target.style.transform = 'scale(1)';
                  }}
                >
                  <i className="fab fa-twitter"></i>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;

