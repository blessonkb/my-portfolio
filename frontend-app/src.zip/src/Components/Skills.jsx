const Skills = () => {
  const skills = [
    { name: 'React', level: 90, color: '#e34c26' },
    { name: 'JavaScript', level: 85, color: '#e34c26' },
    { name: 'Node.js', level: 80, color: '#e34c26' },
    { name: 'Express.js', level: 85, color: '#e34c26' },
    { name: 'MongoDB', level: 75, color: '#e34c26' },
    { name: 'CSS/Bootstrap', level: 90, color: '#e34c26' },
    { name: 'HTML5', level: 95, color: '#e34c26' },
    { name: 'Git/GitHub', level: 80, color: '#e34c26' }
  ];

  return (
    <section 
      id="skills" 
      style={{ 
        backgroundColor: 'white',
        padding: '5rem 0',
        minHeight: '100vh'
      }}
    >
      <div className="container">
        <h2 
          className="text-center mb-5"
          style={{ 
            fontSize: '2.5rem', 
            fontWeight: 'bold',
            color: '#3b3939',
            marginBottom: '4rem'
          }}
        >
          Skills & Technologies
        </h2>
        
        <div className="row g-4">
          {skills.map((skill, index) => (
            <div key={index} className="col-lg-6 col-md-12">
              <div className="mb-3">
                <div className="d-flex justify-content-between mb-2">
                  <span 
                    style={{ 
                      color: '#3b3939',
                      fontSize: '1.1rem',
                      fontWeight: '500'
                    }}
                  >
                    {skill.name}
                  </span>
                  <span 
                    style={{ 
                      color: '#dc3545',
                      fontSize: '0.9rem',
                      fontWeight: '500'
                    }}
                  >
                    {skill.level}%
                  </span>
                </div>
                <div 
                  style={{
                    width: '100%',
                    height: '10px',
                    backgroundColor: '#2a2a2a',
                    borderRadius: '5px',
                    overflow: 'hidden'
                  }}
                >
                  <div 
                    style={{
                      width: `${skill.level}%`,
                      height: '100%',
                      backgroundColor: skill.color,
                      transition: 'width 1s ease-in-out',
                      borderRadius: '5px'
                    }}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Technology Cards
        <div className="row g-4 mt-5">
          <div className="col-12">
            <h3 
              className="text-center mb-4"
              style={{ 
                color: '#3b3939',
                fontSize: '1.8rem',
                fontWeight: 'bold'
              }}
            >
              Technologies I Work With
            </h3>
            <div className="d-flex flex-wrap justify-content-center gap-3">
              <div 
                style={{
                  padding: '1.5rem 2rem',
                  backgroundColor: '#2a2a2a',
                  borderRadius: '10px',
                  color: 'white',
                  fontSize: '1.1rem',
                  fontWeight: '500',
                  transition: 'all 0.3s',
                  border: '1px solid transparent'
                }}
                onMouseEnter={(e) => {
                  e.target.style.backgroundColor = '#dc3545';
                  e.target.style.transform = 'translateY(-5px)';
                  e.target.style.boxShadow = '0 5px 15px rgba(220, 53, 69, 0.3)';
                }}
                onMouseLeave={(e) => {
                  e.target.style.backgroundColor = '#2a2a2a';
                  e.target.style.transform = 'translateY(0)';
                  e.target.style.boxShadow = 'none';
                }}
              >
                React
              </div>
              <div 
                style={{
                  padding: '1.5rem 2rem',
                  backgroundColor: '#2a2a2a',
                  borderRadius: '10px',
                  color: 'white',
                  fontSize: '1.1rem',
                  fontWeight: '500',
                  transition: 'all 0.3s',
                  border: '1px solid transparent'
                }}
                onMouseEnter={(e) => {
                  e.target.style.backgroundColor = '#dc3545';
                  e.target.style.transform = 'translateY(-5px)';
                  e.target.style.boxShadow = '0 5px 15px rgba(220, 53, 69, 0.3)';
                }}
                onMouseLeave={(e) => {
                  e.target.style.backgroundColor = '#2a2a2a';
                  e.target.style.transform = 'translateY(0)';
                  e.target.style.boxShadow = 'none';
                }}
              >
                Node.js
              </div>
              <div 
                style={{
                  padding: '1.5rem 2rem',
                  backgroundColor: '#2a2a2a',
                  borderRadius: '10px',
                  color: 'white',
                  fontSize: '1.1rem',
                  fontWeight: '500',
                  transition: 'all 0.3s',
                  border: '1px solid transparent'
                }}
                onMouseEnter={(e) => {
                  e.target.style.backgroundColor = '#dc3545';
                  e.target.style.transform = 'translateY(-5px)';
                  e.target.style.boxShadow = '0 5px 15px rgba(220, 53, 69, 0.3)';
                }}
                onMouseLeave={(e) => {
                  e.target.style.backgroundColor = '#2a2a2a';
                  e.target.style.transform = 'translateY(0)';
                  e.target.style.boxShadow = 'none';
                }}
              >
                Express
              </div>
              <div 
                style={{
                  padding: '1.5rem 2rem',
                  backgroundColor: '#2a2a2a',
                  borderRadius: '10px',
                  color: 'white',
                  fontSize: '1.1rem',
                  fontWeight: '500',
                  transition: 'all 0.3s',
                  border: '1px solid transparent'
                }}
                onMouseEnter={(e) => {
                  e.target.style.backgroundColor = '#dc3545';
                  e.target.style.transform = 'translateY(-5px)';
                  e.target.style.boxShadow = '0 5px 15px rgba(220, 53, 69, 0.3)';
                }}
                onMouseLeave={(e) => {
                  e.target.style.backgroundColor = '#2a2a2a';
                  e.target.style.transform = 'translateY(0)';
                  e.target.style.boxShadow = 'none';
                }}
              >
                MongoDB
              </div>
              <div 
                style={{
                  padding: '1.5rem 2rem',
                  backgroundColor: '#2a2a2a',
                  borderRadius: '10px',
                  color: 'white',
                  fontSize: '1.1rem',
                  fontWeight: '500',
                  transition: 'all 0.3s',
                  border: '1px solid transparent'
                }}
                onMouseEnter={(e) => {
                  e.target.style.backgroundColor = '#dc3545';
                  e.target.style.transform = 'translateY(-5px)';
                  e.target.style.boxShadow = '0 5px 15px rgba(220, 53, 69, 0.3)';
                }}
                onMouseLeave={(e) => {
                  e.target.style.backgroundColor = '#2a2a2a';
                  e.target.style.transform = 'translateY(0)';
                  e.target.style.boxShadow = 'none';
                }}
              >
                Bootstrap
              </div>
              <div 
                style={{
                  padding: '1.5rem 2rem',
                  backgroundColor: '#2a2a2a',
                  borderRadius: '10px',
                  color: 'white',
                  fontSize: '1.1rem',
                  fontWeight: '500',
                  transition: 'all 0.3s',
                  border: '1px solid transparent'
                }}
                onMouseEnter={(e) => {
                  e.target.style.backgroundColor = '#dc3545';
                  e.target.style.transform = 'translateY(-5px)';
                  e.target.style.boxShadow = '0 5px 15px rgba(220, 53, 69, 0.3)';
                }}
                onMouseLeave={(e) => {
                  e.target.style.backgroundColor = '#2a2a2a';
                  e.target.style.transform = 'translateY(0)';
                  e.target.style.boxShadow = 'none';
                }}
              >
                JavaScript
              </div>
              <div 
                style={{
                  padding: '1.5rem 2rem',
                  backgroundColor: '#2a2a2a',
                  borderRadius: '10px',
                  color: 'white',
                  fontSize: '1.1rem',
                  fontWeight: '500',
                  transition: 'all 0.3s',
                  border: '1px solid transparent'
                }}
                onMouseEnter={(e) => {
                  e.target.style.backgroundColor = '#dc3545';
                  e.target.style.transform = 'translateY(-5px)';
                  e.target.style.boxShadow = '0 5px 15px rgba(220, 53, 69, 0.3)';
                }}
                onMouseLeave={(e) => {
                  e.target.style.backgroundColor = '#2a2a2a';
                  e.target.style.transform = 'translateY(0)';
                  e.target.style.boxShadow = 'none';
                }}
              >
                HTML/CSS
              </div>
              <div 
                style={{
                  padding: '1.5rem 2rem',
                  backgroundColor: '#2a2a2a',
                  borderRadius: '10px',
                  color: 'white',
                  fontSize: '1.1rem',
                  fontWeight: '500',
                  transition: 'all 0.3s',
                  border: '1px solid transparent'
                }}
                onMouseEnter={(e) => {
                  e.target.style.backgroundColor = '#dc3545';
                  e.target.style.transform = 'translateY(-5px)';
                  e.target.style.boxShadow = '0 5px 15px rgba(220, 53, 69, 0.3)';
                }}
                onMouseLeave={(e) => {
                  e.target.style.backgroundColor = '#2a2a2a';
                  e.target.style.transform = 'translateY(0)';
                  e.target.style.boxShadow = 'none';
                }}
              >
                Git
              </div>
            </div> 
          </div>
        </div> */}
      </div>
    </section>
  );
};

export default Skills;

